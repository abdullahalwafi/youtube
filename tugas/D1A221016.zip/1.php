<?php 
for ($i=1; $i <= 100; $i++) { 
    echo "$i. Saya tidak mengulangi perbuatan itu lagi<br>";
}
?>