<?php 
$a = 1;
for ($x=1; $x <= 10 ; $x++) { 
    echo $a;
    $a = $a + 2;
}
?>